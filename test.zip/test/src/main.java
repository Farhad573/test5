public class main {
    public static void toIntValue() {
        // TODO Auto-generated method stub
        System.out.println("hello world");
    }

    public static void main(String[] args) {
        toIntValue();    }


}
